# tesla-speedometer
tesla inspired speedometer created with pure JavaScript and html canvas
codepen: https://codepen.io/tameemimamdad/pen/vzXVMg

### change speedometer values

drawSpeedo(speed, gear, rpm, topSpeed)
```
drawSpeedo(120,4,.8,160);
```
![](teslahudgif.gif)

![image](https://i.imgur.com/dObfPXD.png)
